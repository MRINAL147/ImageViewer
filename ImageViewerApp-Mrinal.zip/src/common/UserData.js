const UserData = {
  data: {
    id: "8661035776",
    username: "upgrad_sde",
    profile_picture:
      "https://scontent.cdninstagram.com/vp/3c9e4d717f555ee53833199c0229adca/5C82C817/t51.2885-19/s150x150/41947221_725500971134637_2241518422187835392_n.jpg",
    full_name: "UpGrad Education",
    bio: "",
    website: "",
    is_business: false,
    counts: {
      media: 6,
      follows: 3,
      followed_by: 31
    }
  },
  meta: {
    code: 200
  }
};

export default UserData;
