import React, { Component } from "react";
import "./Home.css";
import * as Constants from "../../common/Constants";
import * as Utils from "../../common/Utils";
import * as UtilsUI from "../../common/UtilsUI";
import { withStyles } from "@material-ui/core/styles";
import PropTypes from "prop-types";
import Header from "../../common/header/Header";
import MuiThemeProvider from "material-ui/styles/MuiThemeProvider";
import ImageCard from "./ImageCard";

// import ImageData from "../../common/ImageData";

// inline styles for Material-UI components
const styles = {
  imageCard: {
    marginBottom: 40
  },
  addCommentButton: {
    padding: 0,
    float: "right",
    marginTop: "2%"
  }
};

/**
 * Class component for home page
 * @class Home
 * @extends {Component}
 */
class Home extends Component {
  constructor() {
    super();

    this.searchImageByDescription = this.searchImageByDescription.bind(this);
    this.uploadNewImage = this.uploadNewImage.bind(this);
    this.likeButtonClickHandler = this.likeButtonClickHandler.bind(this);
  }

  state = {
    isDataLoaded: false,
    imageData: [], // array containing all the images posted by the currently logged-in user
    filteredImageData: [], // array containing all the images filtered using search box
    currentSearchValue: "",
    curComment: "" // current comment entered by the user inside the input field for adding comment
  };

  /**
   * Function called before the render method
   * @memberof Home
   */
  componentDidMount() {
    if (
      Utils.isUndefinedOrNullOrEmpty(sessionStorage.getItem("access-token"))
    ) {
      this.props.history.push({
        pathname: "/"
      });
    } else {
      this.getAllImageData();
    }
  }

  /**
   * Function to get all the image data on the home page
   * @memberof Home
   */
  getAllImageData = () => {
    if (
      Utils.isUndefinedOrNullOrEmpty(sessionStorage.getItem("access-token"))
    ) {
      this.props.history.push({
        pathname: "/"
      });
    } else {
      const requestUrl =
        this.props.baseUrl +
        "/media/recent/?access_token=" +
        sessionStorage.getItem("access-token");
      const that = this;
      Utils.makeApiCall(
        requestUrl,
        null,
        null,
        Constants.ApiRequestTypeEnum.GET,
        null,
        responseText => {
          that.setState(
            {
              imageData: JSON.parse(responseText).data
              // imageData: ImageData.data
            },
            function() {
              that.setState({
                isDataLoaded: true
              });
            }
          );
        },
        () => {}
      );
    }
  };

  /**
   * Function to search an image by its description; called when a value is entered by a user in the search box
   * @param event default parameter on which the event is called
   * @memberof Home
   */
  searchImageByDescription = event => {
    let currImageData = [...this.state.imageData];
    const searchValue = event.target.value;
    if (!Utils.isEmpty(searchValue)) {
      let searchResults = [];
      for (var image in currImageData) {
        if (
          !Utils.isUndefinedOrNull(currImageData[image].caption) &&
          currImageData[image].caption.text
            .toLowerCase()
            .includes(searchValue.toLowerCase())
        ) {
          searchResults.push(currImageData[image]);
        }
      }
      this.setState({
        filteredImageData: searchResults,
        currentSearchValue: searchValue
      });
    } else {
      this.setState({ currentSearchValue: searchValue });
    }
  };

  /**
   * Function to upload an image to the list of existing images
   * @param imagePost image post containing all the information about the image to be uploaded
   * @memberof Home
   */
  uploadNewImage = imagePost => {
    let imageData = [...this.state.imageData];
    imageData.unshift(imagePost);
    this.setState({
      imageData: imageData
    });
  };

  /**
   * Event handler called when the heart-shaped like button is clicked
   * @param imagePostIndex index of the image post clicked on
   * @param actionType type of the action to be taken on the image post
   * @memberof Home
   */
  likeButtonClickHandler = (imagePostIndex, actionType) => {
    let dataSource = Utils.isUndefinedOrNullOrEmpty(
      this.state.currentSearchValue
    )
      ? [...this.state.imageData]
      : [...this.state.filteredImageData];
    dataSource = UtilsUI.likeOrUnlikeImage(
      dataSource,
      imagePostIndex,
      actionType
    );
    if (!Utils.isUndefinedOrNull(dataSource)) {
      if (Utils.isUndefinedOrNullOrEmpty(this.state.currentSearchValue)) {
        this.setState({
          imageData: dataSource
        });
      } else {
        this.setState({
          filteredImageData: dataSource
        });
      }
    }
  };

  /**
   * Event handler called when the comment is entered inside the input field for adding a comment on an image
   * @param event default parameter on which event handler is called
   * @memberof Home
   */
  commentChangeHandler = event => {
    this.setState({
      curComment: event.target.value
    });
  };

  /**
   * Event handler called when the add comment button is clicked on an image post
   * @param currentImageIndex current image index on which the comment is to be added
   * @memberof Home
   */
  addCommentClickHandler = currentImageIndex => {
    let dataSource = Utils.isUndefinedOrNullOrEmpty(
      this.state.currentSearchValue
    )
      ? [...this.state.imageData]
      : [...this.state.filteredImageData];
    if (!Utils.isUndefinedOrNullOrEmpty(this.state.curComment)) {
      dataSource = UtilsUI.addUserComment(
        dataSource,
        this.state.curComment,
        currentImageIndex
      );
      if (!Utils.isUndefinedOrNull(dataSource)) {
        if (Utils.isUndefinedOrNullOrEmpty(this.state.currentSearchValue)) {
          this.setState({
            imageData: dataSource,
            curComment: ""
          });
        } else {
          this.setState({
            filteredImageData: dataSource,
            curComment: ""
          });
        }
      }
    }
  };

  /**
   * Function called when the component is rendered
   * @memberof Home
   */
  render() {
    const { classes } = this.props;

    const dataSource = Utils.isUndefinedOrNullOrEmpty(
      this.state.currentSearchValue
    )
      ? this.state.imageData
      : this.state.filteredImageData;

    return this.state.isDataLoaded ? (
      <MuiThemeProvider>
        <div>
          <Header
            showLink={false}
            history={this.props.history}
            showSearch={true}
            searchImageByDescription={this.searchImageByDescription}
            showUpload={true}
            uploadNewImage={this.uploadNewImage}
            showProfile={true}
            enableMyAccount={true}
          />
          <div className="images-main-container">
            <div className="left-column">
              {dataSource.map((image, index) =>
                index % 2 === 0 ? (
                  <ImageCard
                    key={index}
                    image={image}
                    index={index}
                    classes={classes}
                    likeButtonClickHandler={this.likeButtonClickHandler}
                    commentChangeHandler={this.commentChangeHandler}
                    addCommentClickHandler={this.addCommentClickHandler}
                  />
                ) : null
              )}
            </div>
            <div className="right-column">
              {dataSource.map((image, index) =>
                index % 2 !== 0 ? (
                  <ImageCard
                    key={index}
                    image={image}
                    index={index}
                    classes={classes}
                    likeButtonClickHandler={this.likeButtonClickHandler}
                    commentChangeHandler={this.commentChangeHandler}
                    addCommentClickHandler={this.addCommentClickHandler}
                  />
                ) : null
              )}
            </div>
          </div>
        </div>
      </MuiThemeProvider>
    ) : null;
  }
}

Home.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(styles)(Home);
