import React, { Component } from "react";
import "./Profile.css";
import * as Constants from "../../common/Constants";
import * as Utils from "../../common/Utils";
import * as UtilsUI from "../../common/UtilsUI";
import Header from "../../common/header/Header";
import { withStyles } from "@material-ui/core/styles";
import PropTypes from "prop-types";
import MuiThemeProvider from "material-ui/styles/MuiThemeProvider";
import Typography from "@material-ui/core/Typography";
import Modal from "react-modal";
import GridList from "@material-ui/core/GridList";
import GridListTile from "@material-ui/core/GridListTile";
import FormControl from "@material-ui/core/FormControl";
import InputLabel from "@material-ui/core/InputLabel";
import Input from "@material-ui/core/Input";
import FormHelperText from "@material-ui/core/FormHelperText";
import Button from "@material-ui/core/Button";
import FavoriteBorder from "@material-ui/icons/FavoriteBorder";
import Favorite from "@material-ui/icons/Favorite";
import EditIcon from "@material-ui/icons/Edit";

// import ImageData from "../../common/ImageData";
// import UserData from "../../common/UserData";

const customStyles = {
  content: {
    top: "50%",
    left: "50%",
    right: "auto",
    bottom: "auto",
    marginRight: "-50%",
    transform: "translate(-50%, -50%)"
  }
};

// inline styles for Material-UI components
const styles = {
  editIconButton: {
    height: 45,
    width: 45
  },
  imagesGridList: {
    margin: "15px !important"
  }
};

/**
 * Class component for profile page
 * @class Profile
 * @extends {Component}
 */
class Profile extends Component {
  constructor() {
    super();

    this.fullNameChangeHandler = this.fullNameChangeHandler.bind(this);
  }

  state = {
    isImageDataLoaded: false,
    isUserDataLoaded: false,
    currentUserDetails: {}, // object containing details of the currently logged-in user
    imageData: [], // array containing all the images posted by the currently logged-in user
    fullName: "", // full name entered by the user in the edit full name modal
    fullNameRequired: Constants.DisplayClassname.DISPLAY_NONE,
    isEditFullNameModalOpen: false, // boolean value indicating if the edit full name modal is open; TRUE for open and FALSE for close
    isImageModalOpen: false, // boolean value indicating if the image modal is open; TRUE for open and FALSE for close
    // object containing the current image details
    selectedImageDetails: {
      imageUrl: "",
      description: "",
      like: "",
      numberOfLikes: 0,
      index: 0,
      comment: ""
    },
    currentImage: "",
    curstoryline: "",
    curLike: false,
    curLikes: "0",
    curIndex: 0,
    curComment: ""
  };

  /**
   * Function called before the render method
   * @memberof Profile
   */
  componentDidMount() {
    if (
      Utils.isUndefinedOrNullOrEmpty(sessionStorage.getItem("access-token"))
    ) {
      this.props.history.push({
        pathname: "/"
      });
    } else {
      this.getAllUserData();
      this.getAllImageData();
    }
  }

  /**
   * Function to get all the user data on the profile page
   * @memberof Profile
   */
  getAllUserData = () => {
    const requestUrl =
      this.props.baseUrl +
      "?access_token=" +
      sessionStorage.getItem("access-token");
    const that = this;
    Utils.makeApiCall(
      requestUrl,
      null,
      null,
      Constants.ApiRequestTypeEnum.GET,
      null,
      responseText => {
        that.setState(
          {
            currentUserDetails: JSON.parse(responseText).data,
            profileImage: JSON.parse(responseText).data.profile_picture,
            fullname: JSON.parse(responseText).data.full_name,
            username: JSON.parse(responseText).data.username,
            posts: JSON.parse(responseText).data.counts.media,
            follows: JSON.parse(responseText).data.counts.follows,
            followedBy: JSON.parse(responseText).data.counts.followed_by
          },
          function() {
            that.setState({
              isUserDataLoaded: true
            });
          }
        );
      },
      () => {}
    );
  };

  /**
   * Function to get all the image data on the profile page
   * @memberof Profile
   */
  getAllImageData = () => {
    const requestUrl =
      this.props.baseUrl +
      "/media/recent/?access_token=" +
      sessionStorage.getItem("access-token");
    const that = this;
    Utils.makeApiCall(
      requestUrl,
      null,
      null,
      Constants.ApiRequestTypeEnum.GET,
      null,
      responseText => {
        that.setState(
          {
            imageData: JSON.parse(responseText).data
            // imageData: ImageData.data
          },
          function() {
            that.setState({
              isImageDataLoaded: true
            });
          }
        );
      },
      () => {}
    );
  };

  /**
   * Event handler called when the edit icon button is clicked to open a modal for editing full name
   * @memberof Profile
   */
  openModalForEditFullName = () => {
    this.setState({
      isEditFullNameModalOpen: true
    });
  };

  /**
   * Event handler called when the modal for editing full name is closed
   * @memberof Profile
   */
  closeModalForEditFullName = () => {
    this.setState({
      isEditFullNameModalOpen: false,
      fullName: "",
      fullNameRequired: Constants.DisplayClassname.DISPLAY_NONE
    });
  };

  fullNameChangeHandler = event => {
    this.setState({
      fullName: event.target.value
    });
  };

  /**
   * Event handler called when the Update button inside the modal for editing full name is clicked to update the full name of the currently logged-in user
   * @memberof Profile
   */
  updateFullNameClickHandler = () => {
    let fullName_validation_classname = UtilsUI.findValidationMessageClassname(
      this.state.fullName,
      Constants.ValueTypeEnum.FORM_FIELD
    );
    if (
      fullName_validation_classname === Constants.DisplayClassname.DISPLAY_BLOCK
    ) {
      this.setState({
        fullNameRequired: fullName_validation_classname
      });
    } else {
      let userDetails = { ...this.state.currentUserDetails };
      userDetails.full_name = this.state.fullName;
      this.setState({
        currentUserDetails: userDetails
      });
      this.closeModalForEditFullName();
    }
  };

  /**
   * Function to open a modal for image
   * @memberof Profile
   */
  openImageModal = () => {
    this.setState({
      isImageModalOpen: true
    });
  };

  /**
   * Event handler called when the image modal is closed
   * @memberof Profile
   */
  closeImageModal = () => {
    this.setState({
      isImageModalOpen: false
    });
  };

  /**
   * Event handler called when an image in the grid list is clicked
   * @memberof Profile
   */
  imageClickHandler = (url, desc, like, numberOfLikes, index) => {
    Utils.isUndefinedOrNull(desc) ? (desc = "") : (desc = desc.text);
    this.openImageModal();
    let currentSelectedImageDetails = { ...this.state.selectedImageDetails };
    currentSelectedImageDetails.imageUrl = url;
    currentSelectedImageDetails.description = desc;
    currentSelectedImageDetails.like = like;
    currentSelectedImageDetails.numberOfLikes = numberOfLikes;
    currentSelectedImageDetails.index = index;
    this.setState({
      currentImage: url,
      curstoryline: desc,
      curLike: like,
      curLikes: numberOfLikes,
      curIndex: index
    });
  };

  /**
   * Event handler called when the heart-shaped like button is clicked inside the image modal
   * @param imagePostIndex index of the image post clicked on
   * @param actionType type of the action to be taken on the image post
   * @memberof Profile
   */
  likeButtonClickHandler = actionType => {
    let curImageData = [...this.state.imageData];
    const imagePostIndex = this.state.curIndex;
    curImageData = UtilsUI.likeOrUnlikeImage(
      curImageData,
      imagePostIndex,
      actionType
    );
    let isLiked = null;
    switch (actionType) {
      case Constants.HeartButtonAction.LIKE:
        isLiked = true;
        break;
      case Constants.HeartButtonAction.UNLIKE:
        isLiked = false;
        break;
      default:
        return;
    }
    let curNumberOfLikes = curImageData[imagePostIndex].likes.count;
    if (!Utils.isUndefinedOrNull(curImageData)) {
      this.setState({
        imageData: curImageData,
        curLike: isLiked,
        curLikes: curNumberOfLikes
      });
    }
  };

  /**
   * Event handler called when the add comment button is clicked on an image post
   * @memberof Profile
   */
  addCommentClickHandler = () => {
    let curImageData = [...this.state.imageData];
    if (!Utils.isUndefinedOrNullOrEmpty(this.state.curComment)) {
      curImageData = UtilsUI.addUserComment(
        curImageData,
        this.state.curComment,
        this.state.curIndex
      );
      if (!Utils.isUndefinedOrNull(curImageData)) {
        this.setState({
          imageData: curImageData,
          curComment: ""
        });
      }
    }
  };

  /**
   * Function called when the component is rendered
   * @memberof Profile
   */
  render() {
    const { classes } = this.props;
    return this.state.isUserDataLoaded && this.state.isImageDataLoaded ? (
      <div>
        <MuiThemeProvider>
          <div>
            <Header
              showLink={true}
              history={this.props.history}
              showSearch={false}
              showUpload={false}
              showProfile={true}
              enableMyAccount={false}
            />
            <div className="profile-main-container">
              <div className="user-info-container">
                <div className="profile-picture-container">
                  <img
                    className="profile-image"
                    src={this.state.currentUserDetails.profile_picture}
                    alt=""
                  />
                </div>

                <div className="information-container">
                  <div className="username-container">
                    <div className="username">
                      {this.state.currentUserDetails.username}
                    </div>
                  </div>

                  <div className="count-container">
                    <div className="posts">
                      Posts: {this.state.currentUserDetails.counts.media}
                    </div>
                    <div className="posts">
                      Follows: {this.state.currentUserDetails.counts.follows}
                    </div>
                    <div className="posts">
                      Followed By:{" "}
                      {this.state.currentUserDetails.counts.followed_by}
                    </div>
                  </div>

                  <div className="full-name-container">
                    <span className="fullname">
                      {this.state.currentUserDetails.full_name}
                    </span>
                    <Button
                      variant="fab"
                      color="secondary"
                      className={classes.editIconButton}
                      aria-label="Edit"
                      onClick={this.openModalForEditFullName}
                    >
                      <EditIcon />
                    </Button>
                  </div>
                </div>
              </div>
              {!Utils.isUndefinedOrNull(this.state.imageData) ? (
                <GridList
                  cellHeight={350}
                  cols={3}
                  className={classes.imagesGridList}
                >
                  {this.state.imageData.map((image, index) => (
                    <GridListTile
                      onClick={() =>
                        this.imageClickHandler(
                          image.images.standard_resolution.url,
                          image.caption,
                          image.curLike,
                          image.likes.count,
                          index
                        )
                      }
                      className="image-tile"
                      key={"grid" + image.id}
                    >
                      <img
                        src={image.images.standard_resolution.url}
                        className="movie"
                        alt={
                          Utils.isUndefinedOrNullOrEmpty(image.caption)
                            ? ""
                            : image.caption.text
                        }
                      />
                    </GridListTile>
                  ))}
                </GridList>
              ) : null}
            </div>
          </div>
        </MuiThemeProvider>

        <Modal
          ariaHideApp={false}
          isOpen={this.state.isEditFullNameModalOpen}
          contentLabel="Edit Name"
          onRequestClose={this.closeModalForEditFullName}
          style={customStyles}
        >
          <MuiThemeProvider>
            <div>
              <Typography variant="headline" component="h2">
                Edit
              </Typography>
              <br />
              <FormControl required>
                <InputLabel htmlFor="fullname">Full Name</InputLabel>
                <Input
                  id="fullname"
                  type="text"
                  onChange={this.fullNameChangeHandler}
                />
                <FormHelperText className={this.state.fullNameRequired}>
                  <span className="red">required</span>
                </FormHelperText>
              </FormControl>
              <br />
              <br />
              <br />

              <Button
                className="button"
                variant="contained"
                color="primary"
                onClick={this.updateFullNameClickHandler}
              >
                Update
              </Button>
              <br />
            </div>
          </MuiThemeProvider>
        </Modal>

        <Modal
          ariaHideApp={false}
          isOpen={this.state.isImageModalOpen}
          contentLabel="Login"
          onRequestClose={this.closeImageModal}
          style={customStyles}
        >
          <MuiThemeProvider>
            <div className="image-modal-container">
              <div className="image-modal-left-container">
                <img src={this.state.currentImage} className="image" alt="" />
              </div>

              <div className="image-modal-right-container">
                <div className="modal-user-info-container">
                  <img
                    src={this.state.currentUserDetails.profile_picture}
                    className="user-profile-image"
                    alt=""
                  />
                  <div className="user-information">
                    <span>{this.state.currentUserDetails.username}</span>
                    <br />
                    <br />
                    <span>
                      {!Utils.isUndefinedOrNull(this.state.imageData) &&
                        Utils.formatDate(
                          this.state.imageData[this.state.curIndex].created_time
                        )}
                    </span>
                  </div>
                </div>

                <hr className="custom-horizontal-rule" />
                {this.state.curstoryline.split("#")[0]}
                <br />

                <div className="hashtags-container">
                  {!Utils.isUndefinedOrNull(this.state.imageData) &&
                    this.state.imageData[this.state.curIndex].tags.map(
                      (tag, i) => "#" + tag + " "
                    )}
                </div>

                <div>
                  {Utils.isUndefinedOrNull(this.state.curLike) ||
                  !this.state.curLike ? (
                    <FavoriteBorder
                      onClick={() =>
                        this.likeButtonClickHandler(
                          Constants.HeartButtonAction.LIKE
                        )
                      }
                      className="black"
                      fontSize="large"
                    />
                  ) : (
                    <Favorite
                      onClick={() =>
                        this.likeButtonClickHandler(
                          Constants.HeartButtonAction.UNLIKE
                        )
                      }
                      className="red"
                      fontSize="large"
                    />
                  )}
                  <div className="likes">
                    {this.state.curLikes > Number("0")
                      ? this.state.curLikes
                      : 0}{" "}
                    likes
                  </div>
                  <br />

                  <div className="comments-container">
                    {!Utils.isUndefinedOrNull(this.state.imageData) &&
                      !Utils.isUndefinedOrNull(
                        this.state.imageData[this.state.curIndex].commentList
                      ) &&
                      this.state.imageData[this.state.curIndex].commentList.map(
                        comment => (
                          <div key={comment.id} className="comment">
                            <span className="username-who-commented">
                              {comment.username}:
                            </span>
                            &nbsp;&nbsp;{comment.comment}
                          </div>
                        )
                      )}
                  </div>

                  <div className="add-comment-container">
                    <FormControl className="add-comment-formcontrol">
                      <InputLabel htmlFor="Add a comment">
                        {" "}
                        Add a comment
                      </InputLabel>
                      <Input
                        id="addAComment"
                        value={this.state.curComment}
                        onChange={event =>
                          this.setState({ curComment: event.target.value })
                        }
                      />
                    </FormControl>
                    &nbsp;&nbsp;
                    <FormControl>
                      <Button
                        onClick={this.addCommentClickHandler}
                        variant="contained"
                        color="primary"
                      >
                        ADD
                      </Button>
                    </FormControl>
                  </div>
                </div>
              </div>
            </div>
          </MuiThemeProvider>
        </Modal>
      </div>
    ) : null;
  }
}

Profile.propTypes = {
  classes: PropTypes.object.isRequired
};

export default withStyles(styles)(Profile);
